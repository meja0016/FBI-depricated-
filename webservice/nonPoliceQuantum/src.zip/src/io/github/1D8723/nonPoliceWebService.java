package io.github.1D8723

public class nonPoliceWebService{

	public static void main(String[] args){
		System.out.prinln("nonPoliceHello");
	}

}