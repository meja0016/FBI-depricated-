
public class nonPolice9 {

	public int add(int a,int b) {
		return a + b;
	}
}
