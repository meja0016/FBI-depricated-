 [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12


 $Form = New-Object System.Windows.Forms.Form
 $Form.Text = "FBI Partner"
 $Form.Size = New-Object System.Drawing.Size(200,200)

$l1 = New-Object System.Windows.Forms.label
$l1.Location = New-Object System.Drawing.Size(0,12)
$l1.Size = New-Object System.Drawing.Size(190,13)
$l1.BackColor = "Red"
$l1.ForeColor = "white"
$l1.Text = "                     development"
$Form.Controls.Add($l1)

$l2 = New-Object System.Windows.Forms.label
$l2.Location = New-Object System.Drawing.Size(0,0)
$l2.Size = New-Object System.Drawing.Size(190,15)
$l2.BackColor = "Black"
$l2.ForeColor = "white"
$l2.Text = "                      FBI Partner"
$Form.Controls.Add($l2)

$l2 = New-Object System.Windows.Forms.label
$l2.Location = New-Object System.Drawing.Size(0,25)
$l2.Size = New-Object System.Drawing.Size(190,15)
$l2.BackColor = "Transparent"
$l2.ForeColor = "Black"
$l2.Text = "     Authorization Code"
$Form.Controls.Add($l2)


$tb02 = New-Object System.Windows.Forms.TextBox  
$tb02.Location = New-Object System.Drawing.Point(20,70)  
$tb02.Size = New-Object System.Drawing.Size(135,23)  
$Form.Controls.Add($tb02)  
  
    $Button = New-Object System.Windows.Forms.Button
    $Button.Location = New-Object System.Drawing.Size(20,100)
    $Button.Size = New-Object System.Drawing.Size(135,25)
    $Button.Text = ""

    $Button2 = New-Object System.Windows.Forms.Button
    $Button2.Location = New-Object System.Drawing.Size(20,129)
    $Button2.Size = New-Object System.Drawing.Size(135,23)
    $Button2.Text = "Start"

    $Button.Add_Click(
        {    
         Invoke-WebRequest -Uri https://receive-smss.com/sms/16467058234/ -OutFile sms.html
         $i = ((Get-Content .\sms.html | findstr "github.com").replace('@github.com #<span class="btn22cp1" data-clipboard-text=','').replace('</b></span></span></div>','') | select -First 1).Split("<br>").Split('"').replace('"    ','')

         $tb02.Text = echo $i | Select-Object -Unique
           Remove-Item sms.html
        }
 
    )
    $Form.Controls.Add($Button)
 
    $form.ShowDialog()