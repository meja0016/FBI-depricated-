import java.io.*;  
import java.util.Scanner;

/* can read files from excel in develpment, csv*/

public abstract class nonPoliceDAOExcel implements nonPoliceDAO {

	public static void main(String[] args){
	try{
		Scanner sc = new Scanner(new File("../../wall.csv"));  
			sc.useDelimiter(",");

		while (sc.hasNext())  //returns a boolean value  
		{  
			System.out.print(sc.next());  //find and returns the next complete token from this scanner  
		}   
		sc.close();
	}catch(Exception e){
	}
	}

	/*
	public String getView(){
		File file = new File("C:\Users\Custom-tc-cen11\Desktop\nonPolice\WEB-INF\src");
		OutputStream output = file.getOutputStream();
		return "<div><h2><font color=navyblue>Wall View</font></h2>1,kindergarten2,univeristy3,pankau<br></div>";
		return output.toString();
	}
	*/
}