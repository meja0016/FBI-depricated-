package com.tarrentcounty.partner

public class nonPolice{

	public static void main(String[] args){
		System.out.prinln("nonPoliceHello");
	}

}