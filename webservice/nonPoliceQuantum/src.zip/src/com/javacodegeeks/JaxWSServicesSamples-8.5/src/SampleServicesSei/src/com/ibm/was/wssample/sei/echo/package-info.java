@javax.xml.bind.annotation.XmlSchema(namespace = "http://com/ibm/was/wssample/sei/echo/")
package com.ibm.was.wssample.sei.echo;
