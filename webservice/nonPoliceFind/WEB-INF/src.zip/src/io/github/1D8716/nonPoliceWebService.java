package io.github.1D8723

public class nonPoliceWebService{

	public static void main(String[] args){
		System.out.prinln("nonPoliceHello");
	}

	//page five 03-2102023.pdf
	//FORMATION OF DOCUMENTS
	nonPoliceOperation(nonPoliceCTX(WWI,WWII,1D8723)){
		//1 WebService, 4 Web Service Operations, 400 OTHADOX lines 8-12am
		//1980-2023,2080
		//copy 1y or 2y 2021-2023
	}
}