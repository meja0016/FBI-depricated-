
public interface nonPoliceDOA{
	

	public String getView();


}