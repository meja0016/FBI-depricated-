[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

$form = New-Object System.Windows.Forms.Form
$form.Size = New-Object System.Drawing.Size(230,260)
$form.Text = "FBI"

$desktop= [Environment]::GetFolderPath("Desktop")
$d = date -Format "MM-dd-yyyy"


$b1 = new-object System.Windows.Forms.Button
$b1.location = new-object System.Drawing.Size(10,45)
$b1.Size = new-object System.Drawing.Size(200,40)
$b1.Text = "Availablity"

$b1.Add_click({
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    mkdir -Path "$desktop\$d-availablity" -Force
    Invoke-WebRequest -uri "https://1d8723.github.io/FBI/css/PNG/1D8723.png" -OutFile "$desktop\$d-availablity\1D8723.png"
    Invoke-WebRequest -uri "https://1d8723.github.io/FBI/css/PNG/bundespolizei.PNG" -OutFile "$desktop\$d-availablity\bundespolizei.PNG"
    Invoke-WebRequest -uri "https://1d8723.github.io/FBI/css/PNG/us-flag.png" -OutFile "$desktop\$d-availablity\us-flag.png"
    Invoke-WebRequest -uri "https://bit.ly/1D8726" -OutFile "$desktop\$d-availablity\index-avability.html"
    Invoke-WebRequest -uri "https://1d8723.github.io/css/PNG/fbi-internet-payments.png" -OutFile "$desktop\$d-availablity\fbi-internet-payments.png"
    Invoke-WebRequest -uri "https://1d8723.github.io/FBI/css/PNG/download.png" -OutFile "$desktop\$d-availablity\download.png"
})
$form.Controls.Add($b1)

$b2 = new-object System.Windows.Forms.Button
$b2.location = new-object System.Drawing.Size(10,100)
$b2.Size = new-object System.Drawing.Size(200,40)
$b2.Text = "Availablity Report"
$b2.Add_click({
    New-Item -Path "$desktop\$d-availablity" -Force -Name nonPolicePresentation.html -Value ="<script></script><body style='margin: 0px'><div style='background-color:black'><font color=white><center><h1><b>FBI </b></h1><center></font><div style='background color:red'><center><h2><font color=white>DEVELOPMENT</font></h2></center></div></div><br><table align=center valign=top><tr><td valign=top><h1><font color=navy>Download</font></h1><hr><br><a href=10-02-2023.pptx><img src=css/PNG/download.png></img></a></td><td valign=top><h1><font color=navy>Presentation</font></h1><hr><br><a href=07-24-2023/Slide1.png><img width=600px src='07-24-2023/Slide1.png'></img></a><br><td valign=top width=200px><h1><font color=navy>Marketing</font></h2><hr><br><table><tr><td><img src='https://1d8723.github.io/FBI/css/PNG/1.png' width=200px></img><br><br><img src='https://1d8723.github.io/FBI/css/PNG/2.png' width=200px ></img><br><br><a href=https://quantum computing.ibm.com/login><img src='https://1d8723.github.io/FBI/css/PNG/3.png' width=200px ></img></a><br><sub><a href=nonPolicePresentation.html>Presentation</a></sub></td></tr></table><hr></td></tr></table>"
    New-Item -Path "$desktop\$d-availablity" -Force -Name index.html  -Value "<script></script><body style='margin: 0px'><div style='background-color:black'><font color=white><center><h1><b>FBI </b></h1><center></font><div style='background-color:red'><center><h2><font color=white>DEVELOPMENT</font></h2></center></div></div><br><table align=center valign=top><tr><td valign=top><h1><font color=navy>Download</font></h1><hr><br><a href=nonPolice.zip><img src=css/PNG/download.png></img></a></td><td valign=top><h1><font color=navy>Availability Report</font></h1><hr><br>
    <br>
        <br>nonPoliceImages</br>
    
    <table width=600px>
        <tr><td>US Flag: <img src=us-flag.png></img></td></tr>
        <tr><td>Budnepolizei: <img width=20px src=bundespolizei.png></img></td></tr>
 
        <tr><td>FBI Profile Picture:<img height=200px src=1D8723.png></img>green</td><td></td></tr>
    <tr><td><br><br>nonPoliceApplication<br><br><iframe width=550px src=index-avability.html></iframe></img>green</td></tr>
    <tr><td>Sales<br><img src=https://1d8723.github.io/FBI//css/PNG/quarter.png></img></td></tr>
    <tr><td><img SRC=https://1d8723.github.io/FBI/css/PNG/bundespolizei.PNG></IMG></td></tr>
    </table>

     <br>
    <br><a href=https://1d8723.github.io/FBI/css/PNG/quarter.png><img width=600px src='https://1d8723.github.io/FBI//css/PNG/quarter.png'></img>
    </a><br><td valign=top width=200px><h1><font color=navy>Marketing</font></h2><hr>
    <br><table><tr><td><img src='https://1d8723.github.io/FBI/css/PNG/1.png' width=200px ></img><br>
    <br><img src='https://1d8723.github.io/FBI/css/PNG/2.png' width=200px ></img><br><br><a href=https://quantum-computing.ibm.com/login><img src='https://1d8723.github.io/FBI/css/PNG/3.png' width=200px ></img></a><br><sub><a href=nonPolicePresentation.html>Presentation</a></sub></td></tr></table><hr></td></tr></table>
    <!-- 8AM-8PM Mo-Fr, Sa 10am-6PM; /nonPolice/services/nonPolice?wsdl -->"
    Start-Process "$desktop\$d-availablity\index.html"

})
$form.Controls.Add($b2)

$l4 = New-Object System.Windows.Forms.Label
$l4.Text = "Version Date: $d"
$l4.Font = New-Object System.Drawing.Font("Arial",6,[System.Drawing.FontStyle]::Bold)
$l4.Size = New-Object System.Drawing.Size(230,20)
$l4.Location = New-Object System.Drawing.Size(10,200)
$form.Controls.Add($l4)

$l1 = New-Object System.Windows.Forms.Label
$l1.BackColor = "Black"
$l1.ForeColor = "White"
$l1.Text = "FBI White Colar Crime"
$l1.Size = New-Object System.Drawing.Size(230,20)
$l1.Location = New-Object System.Drawing.Size(0,0)
$form.Controls.Add($l1)

$l2 = New-Object System.Windows.Forms.Label
$l2.BackColor = "red"
$l2.ForeColor = "White"
$l2.Text = "development"
$l2.Location = New-Object System.Drawing.Size(0,20)
$l2.Size = New-Object System.Drawing.Size(230,15)
$form.Controls.Add($l2)

$b0 = new-object System.Windows.Forms.Button
$b0.location = new-object System.Drawing.Size(10,150)
$b0.Size = new-object System.Drawing.Size(200,40)
$b0.Text = "Archive"
$b0.Add_click({
    Compress-Archive -Path "$desktop\$d-availablity\*" -DestinationPath "$desktop\$d.zip"
    Rename-Item -Path "$desktop\$d.zip" -NewName  "$desktop\$d-availability.war"
})
$form.Controls.Add($b0)

$b4 = new-object System.Windows.Forms.Button
$b4.location = new-object System.Drawing.Size(400,400)
$b4.Size = new-object System.Drawing.Size(10,10)
$b4.Text = "Code"
$b4.Add_click({
    $str = ""
    $str = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($str))
    New-Item -Path . -Name "$d\nonPolice.ps1" -ItemType "file" -Value $str

})
$form.Controls.Add($b4)


$form.ShowDialog()




