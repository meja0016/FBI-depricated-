#!/bin/sh
CUR_DIR=`pwd`
cd `dirname ${0}`
.  /opt/IBM/WebSphere/AppServer/profiles/AppSrv03/bin/setupCmdLine.sh
.  /opt/IBM/WebSphere/AppServer/profiles/AppSrv03/firststeps/fbrowser.sh

${JAVA_HOME}/jre/bin/java \
  -classpath ${WAS_HOME}/lib/htmlshell.jar:${WAS_HOME}/plugins/com.ibm.ws.runtime.jar \
  com.ibm.ws.install.htmlshell.Launcher 2> /dev/null > /dev/null \
  --file /opt/IBM/WebSphere/AppServer/profiles/AppSrv03/firststeps/firststeps \
  --width 653 \
  --height 600 \
  --resizable false \
  --icon /opt/IBM/WebSphere/AppServer/profiles/AppSrv03/firststeps/ws16x16.gif \
  --profilepath /opt/IBM/WebSphere/AppServer/profiles/AppSrv03 \
  --cellname f709c6145c52Node02Cell \
  --wasroot ${WAS_HOME} \
  --FirstStepsDefaultBrowser $FirstStepsDefaultBrowser \
  --FirstStepsDefaultBrowserPath $FirstStepsDefaultBrowserPath
  
  cd ${CUR_DIR}
