import java.io.*;  
import java.util.Scanner;

public class nonPoliceDAOExcel implements nonPoliceDAO {

	public static void main(String[] args){
		new nonPoliceDAOExcel().getView();
	}

	
	public String getView(){
	StringBuffer str = new StringBuffer();
	 try{
		
		Scanner sc = new Scanner(new File("../../wall.csv"));  
			sc.useDelimiter(",");

		while (sc.hasNext()){str.append(sc.next());}   
		sc.close();

	  }catch(Exception e){
		System.out.println(e.getMessage());
	  }
		return str.toString();
	}
	
}