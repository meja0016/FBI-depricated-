
public class nonPoliceBusinessDelegate{
	
	public String getWallView(){
		return new nonPoliceFactory().getWallView();
	}

}