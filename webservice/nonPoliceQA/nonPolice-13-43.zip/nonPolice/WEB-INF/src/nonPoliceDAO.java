
public interface nonPoliceDAO{
	

	public String getView();


}