
public class nonPoliceLog{
	
	public nonPoliceLog getInstance(){
			return "";	
	}

	public String getLogger(){
		return "<div><h2><font color=navyblue>Contact</font></h2>nonPoliceHello<br></div>";
	}
	public String info(){
		return "";
	}
	public String error(){
		return "";
	}
	public String debug(){
		return "";
	}


}